# User Module Code
User modules is just a directory to put YOUR additions, stuff like features you coded and modular-stuff you wanna put on J for your own entertainment.

# UMC Rules:
> Must be C code or a PL that can be compiled into J with cl, since i don't plan to implement any custom runner for stuff like Java or JavaScript.

> Must have comments explaining your code or have a `docs.txt` file so people know what the heck you meant by all that nonsense.

> Must NOT contain malicious code.

Have fun!
DON'T ask for DLL support, we won't do that.